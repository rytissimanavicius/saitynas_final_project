package lt.viko.eif.saitynas_final_project.objects;

public class RatingSearch {

}
